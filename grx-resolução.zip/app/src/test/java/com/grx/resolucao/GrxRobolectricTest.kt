package com.grx.resolucao

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [35])
class GrxRobolectricTest {

    @Test
    fun `app name matches GRX RESOLUÇÃO and AI detection builds 3 safe profiles`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("GRX RESOLUÇÃO", appName)

        val detected = ResolutionDatabase.detectCurrentDevice(
            context = context,
            overridePhysicalWidth = 1080,
            overridePhysicalHeight = 2400,
            overridePhysicalDpi = 420
        )
        assertEquals(3, detected.effectiveModel.profiles.size)
        assertTrue(detected.effectiveModel.profiles.all { it.width >= 480 })
    }
}

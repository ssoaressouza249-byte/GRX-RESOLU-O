package com.grx.resolucao

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.grx.resolucao.ui.theme.GrxAmberAlert
import com.grx.resolucao.ui.theme.GrxDeepBlack
import com.grx.resolucao.ui.theme.GrxElectricBlue
import com.grx.resolucao.ui.theme.GrxElectricBlueSoft
import com.grx.resolucao.ui.theme.GrxNeonGreen
import com.grx.resolucao.ui.theme.GrxNeonGreenSoft
import com.grx.resolucao.ui.theme.GrxNeonRed
import com.grx.resolucao.ui.theme.GrxNeonRedSoft
import com.grx.resolucao.ui.theme.GrxResolucaoTheme
import com.grx.resolucao.ui.theme.GrxSurfaceDark
import com.grx.resolucao.ui.theme.GrxTextPrimary
import com.grx.resolucao.ui.theme.GrxTextSecondary
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        SafeResolutionManager.initialize(applicationContext)

        setContent {
            GrxResolucaoTheme {
                GrxSetupScreen()
            }
        }
    }
}

@Composable
fun GrxSetupScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    val uiState by SafeResolutionManager.uiState.collectAsStateWithLifecycle()
    val isOverlayServiceRunning by FloatingResoService.isRunning.collectAsStateWithLifecycle()
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        startFloatingPanelService(context)
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = Settings.canDrawOverlays(context)
                SafeResolutionManager.refreshShizukuStatus()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val overlayPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        hasOverlayPermission = Settings.canDrawOverlays(context)
    }

    Scaffold(
        containerColor = GrxDeepBlack,
        contentWindowInsets = WindowInsets.safeDrawing,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 600.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 20.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hero Neon Header Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
                    border = BorderStroke(2.dp, GrxElectricBlue),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_grx_banner),
                            contentDescription = "Banner Gamer Neon GRX RESOLUÇÃO",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(
                                            Color(0x55050508),
                                            Color(0xE6050508)
                                        )
                                    )
                                )
                        )
                        Column(
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "GRX RESOLUÇÃO",
                                style = MaterialTheme.typography.headlineLarge,
                                color = GrxTextPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            val deviceText = uiState.detectedDevice?.let {
                                "${it.effectiveModel.name} • Nativa ${it.physicalWidth}x${it.physicalHeight}"
                            } ?: "${Build.MANUFACTURER} ${Build.MODEL}"
                            Text(
                                text = deviceText,
                                style = MaterialTheme.typography.labelMedium,
                                color = GrxElectricBlue
                            )
                        }
                    }
                }

                // Passo 1: Sobreposição de Tela
                StepOverlayPermissionCard(
                    isGranted = hasOverlayPermission,
                    onRequestOverlay = {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        overlayPermissionLauncher.launch(intent)
                    }
                )

                // Passo 2: Conectar e Autorizar Shizuku
                StepShizukuCard(
                    shizukuState = uiState.shizukuState,
                    onRequestPermission = {
                        SafeResolutionManager.requestShizukuPermission()
                    },
                    onOpenShizukuApp = {
                        val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                        if (launchIntent != null) {
                            context.startActivity(launchIntent)
                        } else {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("App Shizuku não encontrado. Instale o Shizuku pela Play Store ou GitHub.")
                            }
                        }
                    }
                )

                // Primary CTA: ABRIR PAINEL FLUTUANTE GRX
                Button(
                    onClick = {
                        if (!hasOverlayPermission) {
                            coroutineScope.launch {
                                snackbarHostState.showSnackbar("Ative a permissão de Sobreposição de Tela no Passo 1 primeiro.")
                            }
                            return@Button
                        }

                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            val notifGranted = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.POST_NOTIFICATIONS
                            ) == PackageManager.PERMISSION_GRANTED
                            if (!notifGranted) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                return@Button
                            }
                        }

                        startFloatingPanelService(context)
                        coroutineScope.launch {
                            snackbarHostState.showSnackbar("Painel Flutuante GRX ativado! Toque na bolha vermelha na tela.")
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = GrxNeonRed),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp)
                        .border(1.5.dp, GrxElectricBlue, RoundedCornerShape(14.dp))
                        .testTag("open_floating_panel_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = null,
                        tint = GrxTextPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "ABRIR PAINEL FLUTUANTE GRX",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 13.sp),
                        color = GrxTextPrimary
                    )
                }

                if (isOverlayServiceRunning) {
                    OutlinedButton(
                        onClick = {
                            val stopIntent = Intent(context, FloatingResoService::class.java).apply {
                                action = FloatingResoService.ACTION_STOP
                            }
                            context.startService(stopIntent)
                        },
                        border = BorderStroke(1.5.dp, GrxNeonRed),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("stop_floating_panel_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = null,
                            tint = GrxNeonRed
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ENCERRAR PAINEL FLUTUANTE",
                            style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                            color = GrxNeonRed
                        )
                    }
                }

                // Safety Footer Notice
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
                    border = BorderStroke(1.dp, GrxElectricBlue.copy(alpha = 0.4f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = "Proteção Anti-Falha",
                            tint = GrxElectricBlue,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Trava Anti-Falha de 15s: toda mudança de resolução reverte automaticamente para a original se você não confirmar na tela.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = GrxTextSecondary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StepOverlayPermissionCard(
    isGranted: Boolean,
    onRequestOverlay: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
        border = BorderStroke(
            width = 1.8.dp,
            color = if (isGranted) GrxNeonGreen else GrxElectricBlue
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = "Sobreposição de Tela",
                        tint = GrxElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PASSO 1 • SOBREPOSIÇÃO DE TELA",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                        color = GrxElectricBlue
                    )
                }
                StatusPill(
                    label = if (isGranted) "ATIVO" else "PENDENTE",
                    isOk = isGranted,
                    accentColor = if (isGranted) GrxNeonGreen else GrxNeonRed
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Permite exibir a Bolha Flutuante GRX e o Painel Gamer por cima dos jogos.",
                style = MaterialTheme.typography.bodyMedium,
                color = GrxTextSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
                onClick = onRequestOverlay,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isGranted) GrxNeonGreenSoft else GrxNeonRed
                ),
                border = if (isGranted) BorderStroke(1.dp, GrxNeonGreen) else null,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("step1_overlay_button")
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.OpenInNew,
                    contentDescription = null,
                    tint = if (isGranted) GrxNeonGreen else GrxTextPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isGranted) "SOBREPOSIÇÃO AUTORIZADA" else "ATIVAR SOBREPOSIÇÃO DE TELA",
                    style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                    color = if (isGranted) GrxNeonGreen else GrxTextPrimary
                )
            }
        }
    }
}

@Composable
private fun StepShizukuCard(
    shizukuState: ShizukuConnectionState,
    onRequestPermission: () -> Unit,
    onOpenShizukuApp: () -> Unit
) {
    val isConnected = shizukuState == ShizukuConnectionState.CONNECTED_READY
    val statusColor = when (shizukuState) {
        ShizukuConnectionState.CONNECTED_READY -> GrxNeonGreen
        ShizukuConnectionState.PERMISSION_REQUIRED -> GrxAmberAlert
        ShizukuConnectionState.DISCONNECTED -> GrxNeonRed
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = GrxSurfaceDark),
        border = BorderStroke(
            width = 1.8.dp,
            color = if (isConnected) GrxNeonGreen else GrxElectricBlue
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Shizuku",
                        tint = GrxElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PASSO 2 • SHIZUKU",
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 11.sp),
                        color = GrxElectricBlue
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(statusColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    StatusPill(
                        label = when (shizukuState) {
                            ShizukuConnectionState.CONNECTED_READY -> "CONECTADO"
                            ShizukuConnectionState.PERMISSION_REQUIRED -> "AUTORIZAR"
                            ShizukuConnectionState.DISCONNECTED -> "OFFLINE"
                        },
                        isOk = isConnected,
                        accentColor = statusColor
                    )
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = when (shizukuState) {
                    ShizukuConnectionState.CONNECTED_READY ->
                        "Shizuku conectado e autorizado! Pronto para aplicar wm size e wm density com segurança."
                    ShizukuConnectionState.PERMISSION_REQUIRED ->
                        "Serviço Shizuku detectado! Toque abaixo para conceder permissão ao GRX RESOLUÇÃO."
                    ShizukuConnectionState.DISCONNECTED ->
                        "Inicie o serviço Shizuku (Depuração sem fio ou ADB) e depois autorize o acesso."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = GrxTextSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Button(
                    onClick = onRequestPermission,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isConnected) GrxNeonGreenSoft else GrxNeonRed
                    ),
                    border = if (isConnected) BorderStroke(1.dp, GrxNeonGreen) else null,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("step2_shizuku_permission_button")
                ) {
                    Text(
                        text = when (shizukuState) {
                            ShizukuConnectionState.CONNECTED_READY -> "SHIZUKU AUTORIZADO"
                            ShizukuConnectionState.PERMISSION_REQUIRED -> "AUTORIZAR SHIZUKU"
                            ShizukuConnectionState.DISCONNECTED -> "CONECTAR SHIZUKU"
                        },
                        style = MaterialTheme.typography.labelLarge.copy(fontSize = 10.sp),
                        color = if (isConnected) GrxNeonGreen else GrxTextPrimary
                    )
                }
                OutlinedButton(
                    onClick = onOpenShizukuApp,
                    border = BorderStroke(1.5.dp, GrxElectricBlue),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .height(48.dp)
                        .testTag("open_shizuku_app_button")
                ) {
                    Text(
                        text = "ABRIR APP",
                        style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
                        color = GrxElectricBlue
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPill(label: String, isOk: Boolean, accentColor: Color) {
    Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(fontSize = 10.sp),
        color = accentColor,
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(if (isOk) GrxNeonGreenSoft else GrxNeonRedSoft)
            .border(1.dp, accentColor, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

private fun startFloatingPanelService(context: android.content.Context) {
    val intent = Intent(context, FloatingResoService::class.java).apply {
        action = FloatingResoService.ACTION_START
    }
    ContextCompat.startForegroundService(context, intent)
}

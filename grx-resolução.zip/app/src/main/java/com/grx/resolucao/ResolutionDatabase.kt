package com.grx.resolucao

import android.content.Context
import android.hardware.display.DisplayManager
import android.os.Build
import android.util.DisplayMetrics
import android.view.Display
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class DeviceBrand(val displayName: String, val isPrimary: Boolean) {
    MOTOROLA("Motorola", true),
    POCO("POCO", true),
    SAMSUNG("Samsung", true),
    XIAOMI_REDMI("Xiaomi / Redmi", false),
    REALME("Realme", false),
    INFINIX("Infinix", false)
}

enum class ProfileTier(val label: String, val shortLabel: String, val badgeText: String) {
    LOW("Resolução Baixa", "Baixa", "~75% FPS MAX"),
    MEDIUM("Resolução Média", "Média", "~88% EQUILÍBRIO"),
    HIGH("Resolução Alta", "Alta", "100% NATIVA")
}

data class ResolutionProfile(
    val tier: ProfileTier,
    val width: Int,
    val height: Int,
    val dpi: Int
) {
    val formattedSize: String get() = "${width}x${height}"
    val formattedDpi: String get() = "$dpi DPI"
}

data class DeviceModel(
    val id: String,
    val brand: DeviceBrand,
    val name: String,
    val nativeWidth: Int,
    val nativeHeight: Int,
    val nativeDpi: Int,
    val profiles: List<ResolutionProfile>,
    val aliases: List<String> = emptyList()
) {
    val formattedNative: String get() = "${nativeWidth}x${nativeHeight}"
}

data class DetectedDeviceResult(
    val manufacturer: String,
    val modelName: String,
    val physicalWidth: Int,
    val physicalHeight: Int,
    val stableDpi: Int,
    val matchedDatabaseModel: DeviceModel?,
    val aiCalibratedModel: DeviceModel
) {
    val effectiveModel: DeviceModel get() = matchedDatabaseModel ?: aiCalibratedModel
    val isKnownModel: Boolean get() = matchedDatabaseModel != null
}

object ResolutionDatabase {

    const val MIN_SAFE_WIDTH = 480
    const val MIN_SAFE_HEIGHT = 800
    const val MAX_SAFE_WIDTH = 1440
    const val MAX_SAFE_HEIGHT = 3200
    const val MIN_SAFE_DPI = 160
    const val MAX_SAFE_DPI = 640

    private fun evenRound(value: Float): Int {
        val rounded = value.roundToInt()
        return if (rounded % 2 == 0) rounded else rounded + 1
    }

    /**
     * Calcula os 3 perfis 100% seguros (Baixa ~75%, Média ~88%, Alta 100% nativa ou limite seguro)
     * preservando a proporção exata do painel e respeitando os limites mínimos do Android.
     */
    fun buildSafeProfiles(
        nativeWidth: Int,
        nativeHeight: Int,
        nativeDpi: Int
    ): List<ResolutionProfile> {
        val safeNativeW = nativeWidth.coerceIn(MIN_SAFE_WIDTH, MAX_SAFE_WIDTH)
        val aspect = nativeHeight.toFloat() / nativeWidth.toFloat()
        val safeNativeH = evenRound(safeNativeW * aspect).coerceIn(MIN_SAFE_HEIGHT, MAX_SAFE_HEIGHT)
        val safeNativeDpi = nativeDpi.coerceIn(MIN_SAFE_DPI, MAX_SAFE_DPI)

        fun scaledProfile(tier: ProfileTier, scale: Float): ResolutionProfile {
            val targetW = evenRound(safeNativeW * scale)
                .coerceIn(MIN_SAFE_WIDTH, safeNativeW)
            val actualScale = targetW.toFloat() / safeNativeW.toFloat()
            val targetH = evenRound(safeNativeH * actualScale)
                .coerceIn(MIN_SAFE_HEIGHT, MAX_SAFE_HEIGHT)
            val targetDpi = (safeNativeDpi * actualScale)
                .roundToInt()
                .coerceIn(MIN_SAFE_DPI, MAX_SAFE_DPI)
            return ResolutionProfile(
                tier = tier,
                width = targetW,
                height = targetH,
                dpi = targetDpi
            )
        }

        val low = scaledProfile(ProfileTier.LOW, 0.75f)
        val medium = scaledProfile(ProfileTier.MEDIUM, 0.88f)
        val high = ResolutionProfile(
            tier = ProfileTier.HIGH,
            width = safeNativeW,
            height = safeNativeH,
            dpi = safeNativeDpi
        )

        return listOf(low, medium, high)
    }

    fun validateProfileBounds(
        profile: ResolutionProfile,
        maxAllowedWidth: Int,
        maxAllowedHeight: Int
    ): String? {
        if (profile.width < MIN_SAFE_WIDTH) {
            return "Largura ${profile.width}px abaixo do limite mínimo seguro (${MIN_SAFE_WIDTH}px)."
        }
        if (profile.height < MIN_SAFE_HEIGHT) {
            return "Altura ${profile.height}px abaixo do limite mínimo seguro (${MIN_SAFE_HEIGHT}px)."
        }
        val effectiveMaxW = maxOf(maxAllowedWidth, MAX_SAFE_WIDTH)
        val effectiveMaxH = maxOf(maxAllowedHeight, MAX_SAFE_HEIGHT)
        if (profile.width > effectiveMaxW || profile.height > effectiveMaxH) {
            return "Resolução ${profile.formattedSize} excede o limite máximo suportado pelo display (${effectiveMaxW}x${effectiveMaxH})."
        }
        if (profile.dpi !in MIN_SAFE_DPI..MAX_SAFE_DPI) {
            return "DPI ${profile.dpi} fora da faixa segura ($MIN_SAFE_DPI..$MAX_SAFE_DPI)."
        }
        return null
    }

    private fun createModel(
        id: String,
        brand: DeviceBrand,
        name: String,
        width: Int,
        height: Int,
        dpi: Int,
        aliases: List<String> = emptyList()
    ): DeviceModel {
        return DeviceModel(
            id = id,
            brand = brand,
            name = name,
            nativeWidth = width,
            nativeHeight = height,
            nativeDpi = dpi,
            profiles = buildSafeProfiles(width, height, dpi),
            aliases = aliases
        )
    }

    val allModels: List<DeviceModel> = listOf(
        // Motorola
        createModel("moto_g04", DeviceBrand.MOTOROLA, "Moto G04", 720, 1612, 280, listOf("moto g04", "g04")),
        createModel("moto_g14", DeviceBrand.MOTOROLA, "Moto G14", 1080, 2400, 420, listOf("moto g14", "g14")),
        createModel("moto_g24", DeviceBrand.MOTOROLA, "Moto G24", 720, 1612, 280, listOf("moto g24", "g24")),
        createModel("moto_g34", DeviceBrand.MOTOROLA, "Moto G34", 720, 1600, 280, listOf("moto g34", "g34")),
        createModel("moto_g54", DeviceBrand.MOTOROLA, "Moto G54", 1080, 2400, 420, listOf("moto g54", "g54")),
        createModel("moto_g84", DeviceBrand.MOTOROLA, "Moto G84", 1080, 2400, 420, listOf("moto g84", "g84")),
        createModel("moto_e13", DeviceBrand.MOTOROLA, "Moto E13", 720, 1600, 280, listOf("moto e13", "e13")),
        createModel("moto_edge_40", DeviceBrand.MOTOROLA, "Edge 40", 1080, 2400, 420, listOf("edge 40", "motorola edge 40")),

        // POCO
        createModel("poco_x3_pro", DeviceBrand.POCO, "POCO X3 Pro", 1080, 2400, 440, listOf("poco x3 pro", "x3 pro", "m2102j20sg")),
        createModel("poco_x5_pro", DeviceBrand.POCO, "POCO X5 Pro", 1080, 2400, 440, listOf("poco x5 pro", "x5 pro", "22101320g")),
        createModel("poco_x6_pro", DeviceBrand.POCO, "POCO X6 Pro", 1220, 2712, 480, listOf("poco x6 pro", "x6 pro", "2311drk48g")),
        createModel("poco_m5", DeviceBrand.POCO, "POCO M5", 1080, 2408, 440, listOf("poco m5", "22071219cg")),
        createModel("poco_f5", DeviceBrand.POCO, "POCO F5", 1080, 2400, 440, listOf("poco f5", "23049pcd8g")),

        // Xiaomi / Redmi
        createModel("redmi_note_11", DeviceBrand.XIAOMI_REDMI, "Redmi Note 11", 1080, 2400, 440, listOf("redmi note 11", "2201117tg")),
        createModel("redmi_note_12", DeviceBrand.XIAOMI_REDMI, "Redmi Note 12", 1080, 2400, 440, listOf("redmi note 12", "23021raaeg")),
        createModel("redmi_note_13", DeviceBrand.XIAOMI_REDMI, "Redmi Note 13", 1080, 2400, 440, listOf("redmi note 13", "23129raa4g")),
        createModel("redmi_13c", DeviceBrand.XIAOMI_REDMI, "Redmi 13C", 720, 1600, 320, listOf("redmi 13c", "23100rn82l")),

        // Samsung
        createModel("galaxy_a04", DeviceBrand.SAMSUNG, "Galaxy A04", 720, 1600, 300, listOf("sm-a045", "galaxy a04", "a04")),
        createModel("galaxy_a14", DeviceBrand.SAMSUNG, "Galaxy A14", 1080, 2408, 450, listOf("sm-a145", "sm-a146", "galaxy a14", "a14")),
        createModel("galaxy_a15", DeviceBrand.SAMSUNG, "Galaxy A15", 1080, 2340, 450, listOf("sm-a155", "sm-a156", "galaxy a15", "a15")),
        createModel("galaxy_a24", DeviceBrand.SAMSUNG, "Galaxy A24", 1080, 2340, 450, listOf("sm-a245", "galaxy a24", "a24")),
        createModel("galaxy_a34", DeviceBrand.SAMSUNG, "Galaxy A34", 1080, 2340, 450, listOf("sm-a346", "galaxy a34", "a34")),
        createModel("galaxy_a54", DeviceBrand.SAMSUNG, "Galaxy A54", 1080, 2340, 450, listOf("sm-a546", "galaxy a54", "a54")),
        createModel("galaxy_s21_fe", DeviceBrand.SAMSUNG, "Galaxy S21 FE", 1080, 2400, 420, listOf("sm-g990", "s21 fe")),

        // Realme
        createModel("realme_c55", DeviceBrand.REALME, "Realme C55", 1080, 2400, 440, listOf("rmx3710", "realme c55", "c55")),
        createModel("realme_11x", DeviceBrand.REALME, "Realme 11x", 1080, 2400, 440, listOf("rmx3785", "realme 11x", "11x")),

        // Infinix
        createModel("infinix_hot_30i", DeviceBrand.INFINIX, "Infinix Hot 30i", 720, 1612, 320, listOf("x669", "hot 30i")),
        createModel("infinix_note_30", DeviceBrand.INFINIX, "Infinix Note 30", 1080, 2460, 440, listOf("x6833", "note 30"))
    )

    val primaryBrands: List<DeviceBrand> = listOf(
        DeviceBrand.MOTOROLA,
        DeviceBrand.POCO,
        DeviceBrand.SAMSUNG
    )

    val allBrandsOrdered: List<DeviceBrand> = listOf(
        DeviceBrand.XIAOMI_REDMI,
        DeviceBrand.REALME,
        DeviceBrand.INFINIX,
        DeviceBrand.MOTOROLA,
        DeviceBrand.POCO,
        DeviceBrand.SAMSUNG
    )

    fun modelsForBrand(brand: DeviceBrand): List<DeviceModel> =
        allModels.filter { it.brand == brand }

    fun searchModels(query: String): List<DeviceModel> {
        val normalized = query.trim().lowercase()
        if (normalized.isEmpty()) return allModels
        return allModels.filter { model ->
            model.name.lowercase().contains(normalized) ||
                model.brand.displayName.lowercase().contains(normalized) ||
                model.formattedNative.contains(normalized) ||
                model.aliases.any { it.contains(normalized) }
        }
    }

    /**
     * Assistente IA de Detecção: lê Build.MANUFACTURER, Build.MODEL e a resolução física atual
     * para localizar o modelo na base ou gerar automaticamente 3 perfis seguros.
     */
    fun detectCurrentDevice(
        context: Context,
        overridePhysicalWidth: Int? = null,
        overridePhysicalHeight: Int? = null,
        overridePhysicalDpi: Int? = null
    ): DetectedDeviceResult {
        val manufacturer = Build.MANUFACTURER.orEmpty().trim().ifEmpty { "Android" }
        val modelName = Build.MODEL.orEmpty().trim().ifEmpty { "Dispositivo" }
        val combinedSignature = "$manufacturer $modelName ${Build.DEVICE}".lowercase()

        val (displayW, displayH) = readPhysicalDisplaySize(context)
        val physW = (overridePhysicalWidth ?: displayW).coerceAtLeast(MIN_SAFE_WIDTH)
        val physH = (overridePhysicalHeight ?: displayH).coerceAtLeast(MIN_SAFE_HEIGHT)
        val stableDpi = (overridePhysicalDpi ?: DisplayMetrics.DENSITY_DEVICE_STABLE)
            .coerceIn(MIN_SAFE_DPI, MAX_SAFE_DPI)

        val matched = allModels.firstOrNull { entry ->
            val nameMatch = combinedSignature.contains(entry.name.lowercase())
            val aliasMatch = entry.aliases.any { alias -> combinedSignature.contains(alias) }
            nameMatch || aliasMatch
        }

        val inferredBrand = when {
            combinedSignature.contains("motorola") || combinedSignature.contains("moto") -> DeviceBrand.MOTOROLA
            combinedSignature.contains("poco") -> DeviceBrand.POCO
            combinedSignature.contains("samsung") || combinedSignature.contains("sm-") -> DeviceBrand.SAMSUNG
            combinedSignature.contains("xiaomi") || combinedSignature.contains("redmi") -> DeviceBrand.XIAOMI_REDMI
            combinedSignature.contains("realme") || combinedSignature.contains("rmx") -> DeviceBrand.REALME
            combinedSignature.contains("infinix") -> DeviceBrand.INFINIX
            else -> DeviceBrand.MOTOROLA
        }

        val displayTitle = if (modelName.lowercase().startsWith(manufacturer.lowercase())) {
            modelName
        } else {
            "${manufacturer.replaceFirstChar { it.uppercase() }} $modelName"
        }

        val aiModel = DeviceModel(
            id = "ai_detected_device",
            brand = matched?.brand ?: inferredBrand,
            name = displayTitle,
            nativeWidth = physW,
            nativeHeight = physH,
            nativeDpi = stableDpi,
            profiles = buildSafeProfiles(physW, physH, stableDpi)
        )

        return DetectedDeviceResult(
            manufacturer = manufacturer,
            modelName = modelName,
            physicalWidth = physW,
            physicalHeight = physH,
            stableDpi = stableDpi,
            matchedDatabaseModel = matched,
            aiCalibratedModel = aiModel
        )
    }

    private fun readPhysicalDisplaySize(context: Context): Pair<Int, Int> {
        val displayManager = context.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
        val display: Display? = displayManager?.getDisplay(Display.DEFAULT_DISPLAY)
        if (display != null) {
            val mode = display.mode
            val w = min(mode.physicalWidth, mode.physicalHeight)
            val h = max(mode.physicalWidth, mode.physicalHeight)
            if (w > 0 && h > 0) return w to h
        }

        val metrics = context.resources.displayMetrics
        val w = min(metrics.widthPixels, metrics.heightPixels)
        val h = max(metrics.widthPixels, metrics.heightPixels)
        return (if (w > 0) w else 1080) to (if (h > 0) h else 2400)
    }
}

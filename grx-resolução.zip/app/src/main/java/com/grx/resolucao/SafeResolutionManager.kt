package com.grx.resolucao

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

enum class ShizukuConnectionState {
    DISCONNECTED,
    PERMISSION_REQUIRED,
    CONNECTED_READY
}

data class DisplayStatusSnapshot(
    val physicalSize: String = "--",
    val overrideSize: String? = null,
    val physicalDensity: Int? = null,
    val overrideDensity: Int? = null,
    val activeSizeLabel: String = "Padrão Nativo",
    val activeDpiLabel: String = "Padrão Nativo"
)

data class ResolutionManagerUiState(
    val shizukuState: ShizukuConnectionState = ShizukuConnectionState.DISCONNECTED,
    val isApplying: Boolean = false,
    val countdownSeconds: Int? = null,
    val pendingProfile: ResolutionProfile? = null,
    val pendingDeviceName: String? = null,
    val lastAppliedMessage: String? = null,
    val lastErrorMessage: String? = null,
    val displaySnapshot: DisplayStatusSnapshot = DisplayStatusSnapshot(),
    val detectedDevice: DetectedDeviceResult? = null
)

object SafeResolutionManager {

    private const val SHIZUKU_PERMISSION_REQUEST_CODE = 9042
    private const val ANTI_FAIL_TIMEOUT_SECONDS = 15

    private val scope: CoroutineScope by lazy {
        CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    }

    private val _uiState = MutableStateFlow(ResolutionManagerUiState())
    val uiState: StateFlow<ResolutionManagerUiState> = _uiState.asStateFlow()

    private var appContext: Context? = null
    private var remoteShellService: IRemoteShellService? = null
    private var isBindingUserService = false
    private var listenersRegistered = false
    private var countdownJob: Job? = null

    private val userServiceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remoteShellService = IRemoteShellService.Stub.asInterface(service)
            isBindingUserService = false
            scope.launch { refreshDisplayStatus() }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            remoteShellService = null
            isBindingUserService = false
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshShizukuStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        remoteShellService = null
        isBindingUserService = false
        _uiState.update {
            it.copy(shizukuState = ShizukuConnectionState.DISCONNECTED)
        }
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bindUserServiceIfNeeded()
                }
                refreshShizukuStatus()
            }
        }

    fun initialize(context: Context) {
        val appCtx = context.applicationContext
        appContext = appCtx

        if (!listenersRegistered) {
            listenersRegistered = true
            try {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionResultListener)
            } catch (_: Throwable) {
                // Ignore if Shizuku provider is unavailable on test host
            }
        }

        val initialDetected = ResolutionDatabase.detectCurrentDevice(appCtx)
        _uiState.update { it.copy(detectedDevice = initialDetected) }
        refreshShizukuStatus()
    }

    fun refreshShizukuStatus(): ShizukuConnectionState {
        val state = try {
            if (!Shizuku.pingBinder()) {
                ShizukuConnectionState.DISCONNECTED
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindUserServiceIfNeeded()
                ShizukuConnectionState.CONNECTED_READY
            } else {
                ShizukuConnectionState.PERMISSION_REQUIRED
            }
        } catch (_: Throwable) {
            ShizukuConnectionState.DISCONNECTED
        }

        _uiState.update { it.copy(shizukuState = state) }

        if (state == ShizukuConnectionState.CONNECTED_READY) {
            scope.launch { refreshDisplayStatus() }
        }
        return state
    }

    fun requestShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) {
                _uiState.update {
                    it.copy(
                        shizukuState = ShizukuConnectionState.DISCONNECTED,
                        lastErrorMessage = "Serviço Shizuku não está rodando. Abra o app Shizuku e inicie o serviço primeiro."
                    )
                }
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                refreshShizukuStatus()
            } else {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            }
        } catch (t: Throwable) {
            _uiState.update {
                it.copy(lastErrorMessage = "Falha ao solicitar permissão Shizuku: ${t.message}")
            }
        }
    }

    private fun bindUserServiceIfNeeded() {
        val ctx = appContext ?: return
        if (remoteShellService != null || isBindingUserService) return
        try {
            if (!Shizuku.pingBinder() || Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                return
            }
            isBindingUserService = true
            val args = Shizuku.UserServiceArgs(
                ComponentName(ctx, RemoteShellService::class.java)
            )
                .daemon(false)
                .processNameSuffix("grx_shell")
                .debuggable(BuildConfig.DEBUG)
                .version(BuildConfig.VERSION_CODE)

            Shizuku.bindUserService(args, userServiceConnection)
        } catch (_: Throwable) {
            isBindingUserService = false
        }
    }

    fun validateProfileBounds(profile: ResolutionProfile, maxAllowedWidth: Int, maxAllowedHeight: Int): String? {
        return ResolutionDatabase.validateProfileBounds(profile, maxAllowedWidth, maxAllowedHeight)
    }

    fun applyProfile(deviceName: String, profile: ResolutionProfile) {
        scope.launch {
            _uiState.update { it.copy(isApplying = true, lastErrorMessage = null, lastAppliedMessage = null) }

            val shizukuStatus = refreshShizukuStatus()
            if (shizukuStatus != ShizukuConnectionState.CONNECTED_READY) {
                val err = if (shizukuStatus == ShizukuConnectionState.DISCONNECTED) {
                    "Shizuku desconectado. Inicie o serviço Shizuku para alterar a resolução."
                } else {
                    "Permissão do Shizuku pendente. Autorize o GRX RESOLUÇÃO no Shizuku."
                }
                _uiState.update { it.copy(isApplying = false, lastErrorMessage = err) }
                return@launch
            }

            val detected = _uiState.value.detectedDevice
            val maxW = detected?.physicalWidth ?: ResolutionDatabase.MAX_SAFE_WIDTH
            val maxH = detected?.physicalHeight ?: ResolutionDatabase.MAX_SAFE_HEIGHT
            val validationError = validateProfileBounds(profile, maxW, maxH)
            if (validationError != null) {
                _uiState.update { it.copy(isApplying = false, lastErrorMessage = validationError) }
                return@launch
            }

            val sizeResult = executeShizukuCommand("wm size ${profile.width}x${profile.height}")
            if (sizeResult.isFailure) {
                _uiState.update {
                    it.copy(
                        isApplying = false,
                        lastErrorMessage = "Erro ao aplicar wm size: ${sizeResult.exceptionOrNull()?.message}"
                    )
                }
                return@launch
            }

            val densityResult = executeShizukuCommand("wm density ${profile.dpi}")
            if (densityResult.isFailure) {
                // Roll back size if density failed
                executeShizukuCommand("wm size reset")
                _uiState.update {
                    it.copy(
                        isApplying = false,
                        lastErrorMessage = "Erro ao aplicar wm density: ${densityResult.exceptionOrNull()?.message}"
                    )
                }
                return@launch
            }

            refreshDisplayStatus()
            _uiState.update {
                it.copy(
                    isApplying = false,
                    pendingProfile = profile,
                    pendingDeviceName = deviceName,
                    lastAppliedMessage = "Aplicado: ${profile.formattedSize} @ ${profile.formattedDpi}. Confirme em ${ANTI_FAIL_TIMEOUT_SECONDS}s!"
                )
            }
            startAntiFailCountdown()
        }
    }

    private fun startAntiFailCountdown() {
        countdownJob?.cancel()
        countdownJob = scope.launch {
            for (sec in ANTI_FAIL_TIMEOUT_SECONDS downTo 1) {
                _uiState.update { it.copy(countdownSeconds = sec) }
                delay(1000L)
            }
            // Timer expired without user confirmation -> auto revert safely
            _uiState.update {
                it.copy(
                    countdownSeconds = null,
                    pendingProfile = null,
                    pendingDeviceName = null
                )
            }
            executeResetCommands(autoReverted = true)
        }
    }

    fun confirmAppliedResolution() {
        countdownJob?.cancel()
        countdownJob = null
        val confirmedProfile = _uiState.value.pendingProfile
        _uiState.update {
            it.copy(
                countdownSeconds = null,
                pendingProfile = null,
                pendingDeviceName = null,
                lastErrorMessage = null,
                lastAppliedMessage = if (confirmedProfile != null) {
                    "Resolução confirmada: ${confirmedProfile.formattedSize} (${confirmedProfile.formattedDpi})"
                } else {
                    "Resolução confirmada com segurança!"
                }
            )
        }
    }

    fun resetToDefault() {
        countdownJob?.cancel()
        countdownJob = null
        scope.launch {
            executeResetCommands(autoReverted = false)
        }
    }

    private suspend fun executeResetCommands(autoReverted: Boolean) {
        _uiState.update { it.copy(isApplying = true, lastErrorMessage = null) }
        val status = refreshShizukuStatus()
        if (status != ShizukuConnectionState.CONNECTED_READY) {
            _uiState.update {
                it.copy(
                    isApplying = false,
                    countdownSeconds = null,
                    pendingProfile = null,
                    pendingDeviceName = null,
                    lastErrorMessage = "Não foi possível restaurar: Shizuku indisponível."
                )
            }
            return
        }

        val sizeRes = executeShizukuCommand("wm size reset")
        val densityRes = executeShizukuCommand("wm density reset")
        refreshDisplayStatus()

        if (sizeRes.isSuccess && densityRes.isSuccess) {
            _uiState.update {
                it.copy(
                    isApplying = false,
                    countdownSeconds = null,
                    pendingProfile = null,
                    pendingDeviceName = null,
                    lastAppliedMessage = if (autoReverted) {
                        "Trava Anti-Falha: tempo esgotado! Tela restaurada automaticamente para o padrão original."
                    } else {
                        "Resolução e DPI restaurados para o padrão original do aparelho."
                    }
                )
            }
        } else {
            val err = sizeRes.exceptionOrNull()?.message ?: densityRes.exceptionOrNull()?.message ?: "Erro desconhecido"
            _uiState.update {
                it.copy(
                    isApplying = false,
                    countdownSeconds = null,
                    pendingProfile = null,
                    pendingDeviceName = null,
                    lastErrorMessage = "Falha ao restaurar tela: $err"
                )
            }
        }
    }

    suspend fun refreshDisplayStatus() {
        val ctx = appContext ?: return
        val sizeOut = executeShizukuCommand("wm size").getOrNull().orEmpty()
        val densityOut = executeShizukuCommand("wm density").getOrNull().orEmpty()

        val physicalSize = parseWmValue(sizeOut, "Physical size:")
        val overrideSize = parseWmValue(sizeOut, "Override size:")
        val physicalDensity = parseWmValue(densityOut, "Physical density:")?.toIntOrNull()
        val overrideDensity = parseWmValue(densityOut, "Override density:")?.toIntOrNull()

        val physParts = physicalSize?.split("x")
        val parsedPhysW = physParts?.getOrNull(0)?.toIntOrNull()
        val parsedPhysH = physParts?.getOrNull(1)?.toIntOrNull()

        val updatedDetection = ResolutionDatabase.detectCurrentDevice(
            context = ctx,
            overridePhysicalWidth = parsedPhysW,
            overridePhysicalHeight = parsedPhysH,
            overridePhysicalDpi = physicalDensity
        )

        val fallbackSize = updatedDetection.let { "${it.physicalWidth}x${it.physicalHeight}" }
        val activeSize = overrideSize ?: physicalSize ?: fallbackSize
        val activeDpi = (overrideDensity ?: physicalDensity ?: updatedDetection.stableDpi).toString() + " DPI"

        _uiState.update {
            it.copy(
                detectedDevice = updatedDetection,
                displaySnapshot = DisplayStatusSnapshot(
                    physicalSize = physicalSize ?: fallbackSize,
                    overrideSize = overrideSize,
                    physicalDensity = physicalDensity ?: updatedDetection.stableDpi,
                    overrideDensity = overrideDensity,
                    activeSizeLabel = if (overrideSize != null) "$activeSize (Personalizada)" else "$activeSize (Original)",
                    activeDpiLabel = if (overrideDensity != null) "$activeDpi (Personalizada)" else "$activeDpi (Original)"
                )
            )
        }
    }

    private fun parseWmValue(output: String, prefix: String): String? {
        return output.lineSequence()
            .map { it.trim() }
            .firstOrNull { it.startsWith(prefix, ignoreCase = true) }
            ?.substringAfter(":")
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }

    private suspend fun executeShizukuCommand(command: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            // Ensure UserService binding is requested and wait briefly if connecting
            if (remoteShellService == null) {
                withContext(Dispatchers.Main) { bindUserServiceIfNeeded() }
                var attempts = 0
                while (remoteShellService == null && attempts < 15) {
                    delay(100L)
                    attempts++
                }
            }

            val service = remoteShellService
            if (service != null) {
                val out = service.exec(command)
                if (out.startsWith("ERR")) {
                    return@withContext Result.failure(IllegalStateException(out))
                }
                return@withContext Result.success(out)
            }

            // Fallback via Shizuku.newProcess if UserService did not attach in time
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = method.invoke(null, arrayOf("sh", "-c", command), null, null) as Process
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).use { it.readText() }
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).use { it.readText() }
            val exitCode = process.waitFor()
            if (exitCode == 0) {
                Result.success(stdout.trim())
            } else {
                Result.failure(IllegalStateException(stderr.ifBlank { stdout }.ifBlank { "Exit $exitCode" }))
            }
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }
}
